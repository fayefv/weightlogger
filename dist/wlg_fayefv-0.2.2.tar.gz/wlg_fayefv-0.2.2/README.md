
<h1>WeightLogger</h1>
<h3>A simple app to monitor personal fitness.</h3>
<br>

![demo](https://github.com/fayefv/weightlogger/blob/master/supporting_graphic.png?raw=true)

<p> User may record body weight by selecting 
or entering a calendar date.  Body weight
is plotted over all time or just the 
previous week.  User may also generate an 
email report consisting of the data
in a CSV file and the most recent data plot.</p>
<br>
<p>Future improvements may include more
advanced statistics in the trends section.</p>

